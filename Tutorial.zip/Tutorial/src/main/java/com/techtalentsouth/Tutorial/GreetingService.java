package com.techtalentsouth.Tutorial;

import org.springframework.stereotype.Service;

@Service
public class GreetingService {
	public String greeting() {
		return "NEVER RUN AWAY FROM THE TIME POLICE!!!";
	}
}
